<?php

require __DIR__ . '/frontend.php';
require __DIR__ . '/admin.php';
