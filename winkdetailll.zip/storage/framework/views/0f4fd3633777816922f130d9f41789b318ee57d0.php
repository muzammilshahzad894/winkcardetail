<?php if(!empty($servicesMenus) && count($servicesMenus) > 0): ?>
    <?php $__currentLoopData = $servicesMenus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servicesMenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li>
        <!-- Name -->
        <div class="template-component-booking-service-name">
            <span><?php echo e($servicesMenu->name); ?></span>
            <?php if($servicesMenu->description): ?>
            <a href="#" class="template-component-more-link">
                <span>More...</span>
                <span>Less...</span>
            </a>
            <div class="template-component-more-content">
                <?php echo $servicesMenu->description; ?>

            </div>
            <?php endif; ?>
        </div>

        <!-- Duration -->
        <div class="template-component-booking-service-duration">
            <span class="template-icon-booking-meta-duration"></span>
            <span class="template-component-booking-service-duration-value"><?php echo e($servicesMenu->time); ?></span>
            <span class="template-component-booking-service-duration-unit">min</span>
        </div>

        <?php
        $price = explode('.', $servicesMenu->price);
        ?>
        <!-- Price -->
        <div class="template-component-booking-service-price">
            <span class="template-icon-booking-meta-price"></span>
            <span class="template-component-booking-service-price-currency">$</span>
            <span class="template-component-booking-service-price-value"><?php echo e($price[0]); ?></span>
            <span class="template-component-booking-service-price-unit"><?php echo e($price[1] ?? ''); ?></span>
            <span class="template-component-booking-service-price-decimal"></span>
        </div>

        <!-- Button -->
        <div class="template-component-button-box">
            <a style="cursor: pointer;" class="template-component-button" onclick="addService(this, '<?php echo e($servicesMenu->id); ?>')">Book Now</a>
        </div>

    </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
    <li>
        <div class="template-component-booking-service-name">
            <span>No services found.</span>
        </div>
    </li>
<?php endif; ?><?php /**PATH C:\xampp_8.1\htdocs\Arshan\winkdetailll\resources\views/frontend/ajax/service-menu-ajax.blade.php ENDPATH**/ ?>