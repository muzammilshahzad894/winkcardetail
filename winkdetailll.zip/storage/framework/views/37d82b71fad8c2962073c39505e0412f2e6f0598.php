<!-- JS files -->
<script type="text/javascript" src="<?php echo e(asset('frontend-assets/script/jquery-ui.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('frontend-assets/script/superfish.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('frontend-assets/script/jquery.easing.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('frontend-assets/script/jquery.blockUI.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('frontend-assets/script/jquery.qtip.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('frontend-assets/script/jquery.fancybox.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('frontend-assets/script/isotope.pkgd.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('frontend-assets/script/jquery.actual.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('frontend-assets/script/jquery.flexnav.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('frontend-assets/script/jquery.waypoints.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('frontend-assets/script/sticky.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('frontend-assets/script/jquery.scrollTo.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('frontend-assets/script/jquery.fancybox-media.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('frontend-assets/script/jquery.fancybox-buttons.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('frontend-assets/script/jquery.carouFredSel.packed.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('frontend-assets/script/jquery.responsiveElement.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('frontend-assets/script/jquery.touchSwipe.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('frontend-assets/script/DateTimePicker.min.js')); ?>"></script>
<script type="text/javascript" src="http://maps.google.com/maps/api/js"></script>

<!-- Revolution Slider files -->
<script type="text/javascript" src="<?php echo e(asset('frontend-assets/script/revolution/jquery.themepunch.revolution.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('frontend-assets/script/revolution/jquery.themepunch.tools.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('frontend-assets/script/revolution/extensions/revolution.extension.actions.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('frontend-assets/script/revolution/extensions/revolution.extension.carousel.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('frontend-assets/script/revolution/extensions/revolution.extension.kenburn.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('frontend-assets/script/revolution/extensions/revolution.extension.layeranimation.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('frontend-assets/script/revolution/extensions/revolution.extension.migration.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('frontend-assets/script/revolution/extensions/revolution.extension.navigation.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('frontend-assets/script/revolution/extensions/revolution.extension.parallax.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('frontend-assets/script/revolution/extensions/revolution.extension.slideanims.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('frontend-assets/script/revolution/extensions/revolution.extension.video.min.js')); ?>"></script>

<!-- Plugins files -->
<script type="text/javascript" src="<?php echo e(asset('frontend-assets/plugin/booking/jquery.booking.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('frontend-assets/plugin/contact-form/jquery.contactForm.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('frontend-assets/plugin/newsletter-form/jquery.newsletterForm.js')); ?>"></script>

<!-- Components files -->
<script type="text/javascript" src="<?php echo e(asset('frontend-assets/script/template/jquery.template.tab.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('frontend-assets/script/template/jquery.template.image.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('frontend-assets/script/template/jquery.template.helper.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('frontend-assets/script/template/jquery.template.header.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('frontend-assets/script/template/jquery.template.counter.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('frontend-assets/script/template/jquery.template.gallery.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('frontend-assets/script/template/jquery.template.goToTop.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('frontend-assets/script/template/jquery.template.fancybox.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('frontend-assets/script/template/jquery.template.moreLess.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('frontend-assets/script/template/jquery.template.googleMap.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('frontend-assets/script/template/jquery.template.accordion.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('frontend-assets/script/template/jquery.template.searchForm.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('frontend-assets/script/template/jquery.template.testimonial.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('frontend-assets/script/public.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('frontend-assets/script/public.js')); ?>"></script><?php /**PATH C:\xampp_8.1\htdocs\Arshan\winkdetailll\resources\views/partials/frontend/home-js-files.blade.php ENDPATH**/ ?>