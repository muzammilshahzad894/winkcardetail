

<?php $__env->startSection('content'); ?>
<div class="page-content">
    <?php echo $__env->make('partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container-fluid" id="pos-orders-section">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex justify-content-between">
                            <h4 class="card-title mb-4"> Wash Packages</h4>
                            <p>
                                <a href="<?php echo e(route('admin.wash-packages.create')); ?>" class="btn btn-success waves-effect waves-light">
                                    <i class="mdi mdi-plus me-1"></i> Add Wash Package
                                </a>
                            </p>
                        </div>
                        <div class="table-responsive">
                            <table class="table align-middle table-nowrap mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th class="align-middle">Vehicle Type</th>
                                        <th class="align-middle">Package Name</th>
                                        <th class="align-middle">Price</th>
                                        <th class="align-middle">Time</th>
                                        <th class="align-middle">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if($washPackages && count($washPackages) > 0): ?>
                                    <?php $__currentLoopData = $washPackages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $washPackage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($washPackage->vehicleType->name); ?></td>
                                        <td><?php echo e($washPackage->name); ?></td>
                                        <td>$<?php echo e($washPackage->price); ?></td>
                                        <td><?php echo e($washPackage->time); ?> minutes</td>
                                        <td>
                                            <a href="<?php echo e(route('admin.wash-packages.edit', $washPackage->id)); ?>" class="btn btn-primary btn-sm waves-effect waves-light">
                                                <i class="mdi mdi-pencil me-1"></i> Edit
                                            </a>
                                            <form action="<?php echo e(route('admin.wash-packages.destroy', $washPackage->id)); ?>" method="POST" style="display: inline-block;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger btn-sm waves-effect waves-light" onclick="return confirm('Are you sure you want to delete this Wash Package?');">
                                                    <i class="mdi mdi-trash-can me-1"></i> Delete
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                    <tr>
                                        <td colspan="14">
                                            <p class="text-center">No record found.</p>
                                        </td>
                                    </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="text-center d-flex justify-content-center">
            <?php echo e($washPackages->links()); ?>

        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_8.1\htdocs\Arshan\winkdetailll\resources\views/admin/wash-packages/index.blade.php ENDPATH**/ ?>