

<?php $__env->startSection('content'); ?>
<div class="page-content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="alert alert-success" role="alert">
                    <h4 class="alert-heading">Welcome!</h4>
                    <p>Hi, <?php echo e(Auth::user()->name); ?>. Welcome back to the admin panel.</p>
                    <hr>
                    <p class="mb-0">You are logged in as an admin.</p>
                </div>
            </div>
        </div>
        <!-- end row -->
    </div>
    <!-- container-fluid -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_8.1\htdocs\Arshan\winkdetailll\resources\views/admin/home/index.blade.php ENDPATH**/ ?>