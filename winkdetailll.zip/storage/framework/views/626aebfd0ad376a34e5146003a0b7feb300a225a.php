

<?php $__env->startSection('header'); ?>
<?php echo $__env->make('partials.frontend.booking-header', ['breadcrumbContent' => '
    <div class="template-header-bottom-page-title">
        <h1>Book your wash</h1>
    </div>

    <div class="template-header-bottom-page-breadcrumb">
        <a href="' . route('home') . '">Home</a><span class="template-icon-meta-arrow-right-12"></span>Book your wash
    </div>
'], ['imgClass' => 'template-header-background-1'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="template-component-booking template-section template-main" id="template-booking">

    <!-- Booking form -->
    <form action="<?php echo e(route('booking.store')); ?>" method="POST" onSubmit="return submitBooking();">
        <?php echo csrf_field(); ?>
        <ul>
            <!-- Vehcile list -->

            <li>

                <!-- Step -->
                <div class="template-component-booking-item-header template-clear-fix">
                    <span>
                        <span>1</span>
                        <span>/</span>
                        <span>4</span>
                    </span>
                    <h3>Vehicle type</h3>
                    <h5>Select vehicle type below.</h5>
                </div>

                <!-- Content -->
                <div class="template-component-booking-item-content">

                    <!-- Vehicle list -->
                    <ul class="template-component-booking-vehicle-list">

                        <!-- Vehicle -->
                        <?php if(!empty($vehicleTypes) && count($vehicleTypes) > 0): ?>
                        <?php $__currentLoopData = $vehicleTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicleType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li data-id="<?php echo e($vehicleType->image . '-' . $vehicleType->id); ?>" class="booking-vehicle-list-item" vehicle-type-id="<?php echo e($vehicleType->id); ?>" onclick="vehicleFilter('<?php echo e($vehicleType->image . '-' . $vehicleType->id); ?>')">
                            <div>
                                <div class="<?php echo e($vehicleType->image); ?>"></div>
                                <div><?php echo e($vehicleType->name); ?></div>
                            </div>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                        <li>
                            <div>
                                <div>No vehicle types found.</div>
                            </div>
                        </li>
                        <?php endif; ?>
                    </ul>
                    <input type="hidden" name="vehicle_type_id" id="vehicle_type_id" value="" />

                </div>

            </li>
            <!-- Package list -->


            <li>

                <!-- Step -->
                <div class="template-component-booking-item-header template-clear-fix">
                    <span>
                        <span>2</span>
                        <span>/</span>
                        <span>4</span>
                    </span>
                    <h3>Wash packages</h3>
                    <h5>Which wash is best for your vehicle?</h5>
                </div>

                <!-- Content -->
                <div class="template-component-booking-item-content">

                    <!-- Package list -->
                    <ul class="template-component-booking-package-list">

                    <?php if(!empty($washPackages) && count($washPackages) > 0): ?>
                        <?php $__currentLoopData = $washPackages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $washPackage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li data-id="<?php echo e($washPackage->id); ?>" data-id-vehicle-rel="<?php echo e($washPackage->vehicle_type_id); ?>">

                            <!-- Package -->
                        <li data-id="<?php echo e($washPackage->vehicleType->image . '-' . $washPackage->vehicle_type_id); ?>" data-id-vehicle-rel="<?php echo e($washPackage->vehicleType->image . '-' . $washPackage->vehicle_type_id); ?>" class="booking-package-list-item" wash-package-id="<?php echo e($washPackage->id); ?>">

                            <!-- Header -->
                            <h4 class="template-component-booking-package-name"><?php echo e($washPackage->name); ?></h4>

                            <?php
                            $price = explode('.', $washPackage->price);
                            ?>
                            <!-- Price -->
                            <div class="template-component-booking-package-price">
                                <span class="template-component-booking-package-price-currency">$</span>
                                <span class="template-component-booking-package-price-total"><?php echo e($price[0]); ?></span>
                                <span class="template-component-booking-package-price-decimal"><?php echo e($price[1] ?? ''); ?></span>
                            </div>

                            <!-- Duration -->
                            <div class="template-component-booking-package-duration">
                                <span class="template-icon-booking-meta-duration"></span>
                                <span class="template-component-booking-package-duration-value"><?php echo e($washPackage->time); ?></span>
                                <span class="template-component-booking-package-duration-unit">min</span>
                            </div>

                            <!-- Services -->
                            <?php echo $washPackage->description; ?>


                            <!-- Button -->
                            <div class="template-component-button-box">
                                <a href="#" class="template-component-button package-book-now-btn" onclick="washFilter('<?php echo e($washPackage->id); ?>', '<?php echo e($washPackage->vehicle_type_id); ?>')">
                                    Book Now</a>
                            </div>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?> 
                        <li>
                            <div class="template-component-booking-service-name">
                                <span>No wash packages found.</span>
                            </div>
                        </li>
                        <?php endif; ?>
                    </ul>
                    <input type="hidden" name="wash_package_id" id="wash_package_id" value="" />

                </div>

            </li>
            <!-- Service list -->


            <li>

                <!-- Step -->
                <div class="template-component-booking-item-header template-clear-fix">
                    <span>
                        <span>3</span>
                        <span>/</span>
                        <span>4</span>
                    </span>
                    <h3>Services menu</h3>
                    <h5>A la carte services menu.</h5>
                </div>

                <!-- Content -->
                <div class="template-component-booking-item-content">

                    <!-- Service list -->
                    <ul class="template-component-booking-service-list" id="services-menu-list">
                        
                        <?php if(!empty($servicesMenus) && count($servicesMenus) > 0): ?>
                            <?php $__currentLoopData = $servicesMenus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servicesMenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <!-- Name -->
                                <div class="template-component-booking-service-name">
                                    <span><?php echo e($servicesMenu->name); ?></span>
                                    <?php if($servicesMenu->description): ?>
                                    <a href="#" class="template-component-more-link">
                                        <span>More...</span>
                                        <span>Less...</span>
                                    </a>
                                    <div class="template-component-more-content">
                                        <?php echo $servicesMenu->description; ?>

                                    </div>
                                    <?php endif; ?>
                                </div>

                                <!-- Duration -->
                                <div class="template-component-booking-service-duration">
                                    <span class="template-icon-booking-meta-duration"></span>
                                    <span class="template-component-booking-service-duration-value"><?php echo e($servicesMenu->time); ?></span>
                                    <span class="template-component-booking-service-duration-unit">min</span>
                                </div>

                                <?php
                                $price = explode('.', $servicesMenu->price);
                                ?>
                                <!-- Price -->
                                <div class="template-component-booking-service-price">
                                    <span class="template-icon-booking-meta-price"></span>
                                    <span class="template-component-booking-service-price-currency">$</span>
                                    <span class="template-component-booking-service-price-value"><?php echo e($price[0]); ?></span>
                                    <span class="template-component-booking-service-price-unit"><?php echo e($price[1] ?? ''); ?></span>
                                    <span class="template-component-booking-service-price-decimal"></span>
                                </div>

                                <!-- Button -->
                                <div class="template-component-button-box">
                                    <a style="cursor: pointer;" class="template-component-button" onclick="addService(this, '<?php echo e($servicesMenu->id); ?>')">Book Now</a>
                                </div>

                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                            <li>
                                <div class="template-component-booking-service-name">
                                    <span>No services found.</span>
                                </div>
                            </li>
                        <?php endif; ?>
                    </ul>
                    <input type="hidden" name="services_menu_id[]" id="services_menu_id" value="" />
                </div>

            </li>
            <!-- Summary -->


            <li>

                <!-- Step -->
                <div class="template-component-booking-item-header template-clear-fix">
                    <span>
                        <span>4</span>
                        <span>/</span>
                        <span>4</span>
                    </span>
                    <h3>Booking summary</h3>
                    <h5>Please provide us with your contact information.</h5>
                </div>


                <!-- Content -->
                <div class="template-component-booking-item-content">

                    <ul class="template-component-booking-summary template-clear-fix">

                        <!-- Duration -->
                        <li class="template-component-booking-summary-duration">
                            <div class="template-icon-booking-meta-total-duration"></div>
                            <h5>
                                <span id="hours">0</span>
                                <span>h</span>
                                &nbsp;
                                <span id="minutes">0</span>
                                <span>min</span>
                            </h5>
                            <span>Duration</span>
                        </li>

                        <input type="hidden" name="duration" id="duration" value="" />
                        <!-- Price -->
                        <li class="template-component-booking-summary-price ">
                            <div class="template-icon-booking-meta-total-price"></div>
                            <h5>
                                <span class="template-component-booking-summary-price-symbol">$</span>
                                <span class="template-component-booking-summary-price-value" id="total_price">0.00</span>
                            </h5>
                            <span>Total Price</span>
                        </li>
                        <input type="hidden" name="total_price" id="totalPrice" value="" />

                    </ul>

                </div>

                <!-- Content -->
                <div class="template-component-booking-item-content template-margin-top-reset">

                    <!-- Layout -->
                    <ul class="template-layout-50x50 template-layout-margin-reset template-clear-fix">

                        <!-- First name -->
                        <li class="template-layout-column-left template-margin-bottom-reset">
                            <div class="template-component-form-field">
                                <label for="booking-form-first-name">First Name *</label>
                                <input type="text" name="first_name" id="booking-form-first-name" value="<?php echo e(old('first_name')); ?>" required />
                            </div>
                            <?php if($errors->has('first_name')): ?>
                                <span style="color: red;"><?php echo e($errors->first('first_name')); ?></span>
                            <?php endif; ?>
                        </li>

                        <!-- Second name -->
                        <li class="template-layout-column-right template-margin-bottom-reset">
                            <div class="template-component-form-field">
                                <label for="booking-form-second-name">Second Name *</label>
                                <input type="text" name="second_name" id="booking-form-second-name" value="<?php echo e(old('second_name')); ?>" required />
                            </div>
                            <?php if($errors->has('second_name')): ?>
                                <span style="color: red;"><?php echo e($errors->first('second_name')); ?></span>
                            <?php endif; ?>
                        </li>

                    </ul>

                    <!-- Layout -->
                    <ul class="template-layout-50x50 template-layout-margin-reset template-clear-fix">

                        <!-- E-mail address -->
                        <li class="template-layout-column-left template-margin-bottom-reset">
                            <div class="template-component-form-field">
                                <label for="booking-form-email">E-mail Address *</label>
                                <input type="email" name="email" id="booking-form-email" value="<?php echo e(old('email')); ?>" required />
                            </div>
                            <?php if($errors->has('email')): ?>
                                <span style="color: red;"><?php echo e($errors->first('email')); ?></span>
                            <?php endif; ?>
                        </li>

                        <!-- Phone number -->
                        <li class="template-layout-column-right template-margin-bottom-reset">
                            <div class="template-component-form-field">
                                <label for="booking-form-phone">Phone Number *</label>
                                <input type="text" name="phone_number" id="booking-form-phone" value="<?php echo e(old('phone_number')); ?>" required />
                            </div>
                            <?php if($errors->has('phone_number')): ?>
                                <span style="color: red;"><?php echo e($errors->first('phone_number')); ?></span>
                            <?php endif; ?>
                        </li>

                    </ul>

                    <!-- Layout -->
                    <ul class="template-layout-33x33x33 template-layout-margin-reset template-clear-fix">
                        <!-- Vehicle make -->
                        <li class="template-layout-column-left template-margin-bottom-reset">
                            <div class="template-component-form-field">
                                <label for="booking-form-vehicle-make">Vehicle Make</label>
                                <input type="text" name="vehicle_make" id="booking-form-vehicle-make" value="<?php echo e(old('vehicle_make')); ?>" />
                            </div>
                        </li>

                        <!-- Vehicle model -->
                        <li class="template-layout-column-center template-margin-bottom-reset">
                            <div class="template-component-form-field">
                                <label for="booking-form-vehicle-model">Vehicle Model</label>
                                <input type="text" name="vehicle_model" id="booking-form-vehicle-model" value="<?php echo e(old('vehicle_model')); ?>" />
                            </div>
                        </li>

                        <!-- Booking date -->
                        <li class="template-layout-column-right template-margin-bottom-reset">
                            <div class="template-component-form-field">
                                <label for="booking-form-date">Booking Date *</label>
                                <input type="text" data-field="datetime" name="booking_date" id="booking-form-date" value="<?php echo e(old('booking_date')); ?>" required />
                            </div>
                            <?php if($errors->has('booking_date')): ?>
                                <span style="color: red;"><?php echo e($errors->first('booking_date')); ?></span>
                            <?php endif; ?>
                        </li>

                    </ul>

                    <!-- Layout -->
                    <ul class="template-layout-100 template-layout-margin-reset template-clear-fix">

                        <!-- Message -->
                        <li>
                            <div class="template-component-form-field">
                                <label for="booking-form-message">Message *</label>
                                <textarea rows="1" cols="1" name="message" id="booking-form-message" required><?php echo e(old('message')); ?></textarea>
                            </div>
                            <?php if($errors->has('message')): ?>
                                <span style="color: red;"><?php echo e($errors->first('message')); ?></span>
                            <?php endif; ?>
                        </li>

                    </ul>

                    <!-- Text + submit button -->
                    <div class="template-align-center template-clear-fix template-margin-top-2">
                        <p class="template-padding-reset template-margin-bottom-2">We will confirm your appointment with you by phone or e-mail within 24 hours of receiving your request.</p>
                        <input type="submit" value="Confirm Booking" class="template-component-button" name="" id="booking-form-submit" />
                    </div>

                </div>

            </li>
        </ul>

    </form>
</div>

<script>
    // vehicle type filter
    function vehicleFilter(vehicle_data_id) {
        var booking_package_list_item = $('.booking-package-list-item[data-id-vehicle-rel="' + vehicle_data_id + '"]');
        var wash_package_id = '';
        if(booking_package_list_item.length > 0) {
            wash_package_id = booking_package_list_item.first().attr('wash-package-id');
        }
        var vehicle_type_id = $('.booking-vehicle-list-item[data-id="' + vehicle_data_id + '"]').attr('vehicle-type-id');
        getFilterServiceMenu(vehicle_type_id, wash_package_id);
    }

    function washFilter(vehicle_type_id, wash_package_id) {
        var previousPackageId = $('.booking-package-list-item.template-state-selected').attr('wash-package-id');
        if(previousPackageId !== undefined && previousPackageId == wash_package_id) {
            $('#services-menu-list').html('<li class="template-component-list-item">No services found.</li>');
            return;
        }
        getFilterServiceMenu(vehicle_type_id, wash_package_id);
    }

    function getFilterServiceMenu(vehicle_type_id, wash_package_id) {
        console.log(vehicle_type_id, wash_package_id);
        $.ajax({
            url: "<?php echo e(route('booking.filtered-services-menu')); ?>",
            method: 'GET',
            data: {
                vehicle_type_id: vehicle_type_id,
                wash_package_id: wash_package_id
            },
            success: function(data) {
                $('#services-menu-list').html(data.html);
            }
        });
    }

    function addService(button, service_id) {
        var services_menu_id = $('#services_menu_id').val();
        var services_menu_id_array = services_menu_id ? services_menu_id.split(',') : [];

        var index = services_menu_id_array.indexOf(service_id.toString());
        if (index > -1) {
            services_menu_id_array.splice(index, 1);
        } else {
            services_menu_id_array.push(service_id);
        }

        // Update the input field value
        $('#services_menu_id').val(services_menu_id_array.join(','));

        console.log($('#services_menu_id').val());
    }

    function submitBooking() {
        // append the select vehicle type id to the form data
        var vehicleTypeId = $('.booking-vehicle-list-item.template-state-selected').attr('vehicle-type-id');
        $('#vehicle_type_id').val(vehicleTypeId);

        // append the select wash package id to the form data
        var washPackageId = $('.booking-package-list-item.template-state-selected').attr('wash-package-id');
        $('#wash_package_id').val(washPackageId);

        // get hours and minutes values usign id and append in the duration
        var hours = $('#hours').text();
        console.log('hours', hours);
        var minutes = $('#minutes').text();
        console.log('minutes', minutes);
        var duration = hours + ':' + minutes;
        console.log('duration', duration);
        $('#duration').val(duration);
        // total price
        var totalPrice = $('#total_price').text();
        $('#totalPrice').val(totalPrice);

        return true;
    }

    $(document).ready(function () {
        // Attach event handler to the parent element using event delegation
        $(document).on('click', '.template-component-more-link', function (event) {
            event.preventDefault();
            $(this).siblings('.template-component-more-content').slideToggle();
            $(this).children('span').toggle();
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_8.1\htdocs\Arshan\winkdetailll\resources\views/frontend/booking.blade.php ENDPATH**/ ?>